<html>
<head>
	<title>KDC Shared Job</title>
</head>
<body>
	<p>{{ $messageRefer }}</p>
	
</body>
</html>

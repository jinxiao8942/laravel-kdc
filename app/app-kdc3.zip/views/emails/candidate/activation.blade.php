<html>
<head>
	<title>KDC Activation</title>
</head>
<body>
	<h1>Activate your KDC account</h1>
	<p>To activate your KDC account {{ route('candidate-activate', array($candidate->id, $candidate->activation_code), 'Click Here') }}</p>
</body>
</html>

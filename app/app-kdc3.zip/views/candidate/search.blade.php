<section id="main-search">
	<form>
            
		<fieldset>
            
			<input type="text" placeholder="Keyword" /> <input type="submit" value="" />
            
		</fieldset>

		<p><a href="#">Advanced Search</a></p>
	
	</form>
    
</section>

@extends('admin.master')

@section('content')
    <h1>Dashboard</h1>
@stop

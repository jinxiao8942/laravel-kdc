<section id="main-search">
    <form action="jobs" method="get">
            
        <fieldset>
            
            <input type="text" placeholder="Keyword" name="keyword" /> <input type="submit" value="" />
            
        </fieldset>

        <p><a href="#">Advanced Search</a></p>
    
    </form>
    
</section>

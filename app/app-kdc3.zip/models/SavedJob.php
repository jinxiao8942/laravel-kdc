<?php

class SavedJob extends \Eloquent {

	protected $fillable = [];

}

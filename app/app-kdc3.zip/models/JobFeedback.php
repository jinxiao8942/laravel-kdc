<?php

class JobFeedback extends \Eloquent {

	protected $fillable = [];
	protected $table = 'job_feedback';

}

<?php

class Upload extends \Eloquent {

	protected $fillable = [];

}
